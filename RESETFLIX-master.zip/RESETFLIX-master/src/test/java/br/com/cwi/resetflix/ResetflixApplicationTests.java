package br.com.cwi.resetflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResetflixApplicationTests {

	@Test
	void contextLoads() {
	}

}
