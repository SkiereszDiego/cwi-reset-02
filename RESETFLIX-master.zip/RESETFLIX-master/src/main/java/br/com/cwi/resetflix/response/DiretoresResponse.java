package br.com.cwi.resetflix.response;

public class DiretoresResponse {

}
