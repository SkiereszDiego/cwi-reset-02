package br.com.cwi.resetflix.request;

import java.util.List;

public class CriarDiretorRequest {

}
