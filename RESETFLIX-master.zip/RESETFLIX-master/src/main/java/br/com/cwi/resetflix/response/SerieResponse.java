package br.com.cwi.resetflix.response;

import br.com.cwi.resetflix.domain.Genero;

public class SerieResponse {

}