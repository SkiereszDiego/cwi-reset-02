package br.com.cwi.resetflix.request;

public class CriarSerieRequest {

}
