package br.com.cwi.resetflix.domain;

public enum Genero {
    PREENCHER, OS, GENEROS
}
