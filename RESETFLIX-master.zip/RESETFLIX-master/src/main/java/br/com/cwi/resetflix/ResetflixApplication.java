package br.com.cwi.resetflix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResetflixApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResetflixApplication.class, args);
	}

}
